<?php
//禁用错误报告
error_reporting(0);
//开启一个会话
session_start();
header("Content-Type: text/html;charset=utf-8");
require_once 'conn.php';
if(isset($_POST["username"])&&$_POST["password"])
{
	
 $uname=$_POST["username"];
 $pwd=$_POST["password"];
 
$uname = mysql_real_escape_string($uname);//防止SQL注入
$pwd = mysql_real_escape_string($pwd);//防止SQL注入


$query = "select * from user where uname='".$uname."' and pwd='".$pwd."'";//构建查询语句


$result = mysql_query($query);//执行查询


if (!$result) {
    die("could not to the database\n" . mysql_error());
}
if (mysql_numrows($result)<=0) {
	echo "<script type='text/javascript'>alert('登录错误，请重新登录！');location.href='index.html'</script>";
}else{
while($result_row=mysql_fetch_row(($result)))//取出结果并显示
{
$uid=$result_row[0];
$db_uname=$result_row[1];
$db_pwd=$result_row[2];
$db_bill=$result_row[3];
$_SESSION['user_id']=$db_uname;
echo "欢迎回来".$db_uname." !!</br>";;
echo "用户名为:".$db_uname."</br>";
echo "密码为:".$db_pwd."</br>";
echo "余额为:".$db_bill."</br>";
echo "<hr/>";


}
}
mysql_close($connection);//关闭连接

}else if ($_FILES["file"]["error"] > 0)
  {
  #echo "Error: " . $_FILES["file"]["error"] . "<br />";
  echo $_SESSION['user_id'].", 请选择文件上传!!";
  }
else
  {
  echo "Upload: " . $_FILES["file"]["name"] . "<br />";
  echo "Type: " . $_FILES["file"]["type"] . "<br />";
  echo "Size: " . ($_FILES["file"]["size"] / 1024) . " Kb<br />";
  echo "Stored in: " . $_FILES["file"]["tmp_name"];
	if (file_exists("upload/" . $_FILES["file"]["name"]))
      {
      echo $_FILES["file"]["name"] . " already exists. ";
      }
    else
      {
      move_uploaded_file($_FILES["file"]["tmp_name"],
      "upload/" . $_FILES["file"]["name"]);
      echo "Stored in: " . "upload/" . $_FILES["file"]["name"];
      }
  }
?>
<html>
<body>
<center>
<hr/>
云盘测试——上传
<hr/><hr/>

<form action="" method="post"
enctype="multipart/form-data">
<label for="file">文件名:</label>
<input type="file" name="file" id="file" /> 
<br /><br /><br />
<input type="submit" name="submit" value="提交" />
</form>

</center>
<br /><br />
<?php
echo getcwd() . "<br/>";
#echo dirname(__FILE__/); 

$current_dir = getcwd();
$dir = opendir($current_dir);
echo "direcotry list:<ul>";
while(false !== ($file=readdir($dir))){
if($file != "." && $file != ".."){
echo "<li>$file</li>";
}
}
echo "</ul>";
closedir($dir);

?>
</body>
</html>